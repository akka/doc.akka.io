DROP TABLE event_journal;
DROP TABLE snapshot;
DROP TABLE durable_state;
DROP TABLE akka_projection_timestamp_offset_store;
DROP TABLE akka_projection_management;